package com.example.myquiz;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.res.AssetManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
 TextView totalquestion;
 TextView question;
 Button ansA,ansB,ansC,ansD;
 Button sumbit;
 int score=0;
 int total_question=questionanswer.question.length;
 int currentquestionindex=0;
 String selectedanswer="";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        totalquestion = findViewById(R.id.questions);
        question=findViewById(R.id.wq);
        ansA=findViewById(R.id.ansA);
        ansB=findViewById(R.id.ansB);
        ansC=findViewById(R.id.ansC);
        ansD=findViewById(R.id.ansD);
        sumbit=findViewById(R.id.sumbit);
        ansA.setOnClickListener(this);
        ansB.setOnClickListener(this);
        ansC.setOnClickListener(this);
        ansD.setOnClickListener(this);
        sumbit.setOnClickListener(this);

totalquestion.setText("Total question :"+totalquestion);
loadnewquestion();

ansA.setBackgroundColor(android.R.color.white);
        ansB.setBackgroundColor(android.R.color.white);
        ansC.setBackgroundColor(android.R.color.white);
        ansD.setBackgroundColor(android.R.color.white);

    }

    @Override
    public void onClick(View view) {

        Button clickedbutton=(Button) view;
        if (clickedbutton.getId() == R.id.sumbit) {
         currentquestionindex++;
         loadnewquestion();
         if (selectedanswer.equals(questionanswer.corectans[currentquestionindex])){
             score++;
         }
        }else {
            selectedanswer=clickedbutton.getText().toString();
            clickedbutton.setBackgroundColor(android.R.color.black);
        }

    }
    void loadnewquestion(){
        if(currentquestionindex==total_question){
            finishquiz();
            return;
        }
        question.setText(questionanswer.question[currentquestionindex]);
        ansA.setText(questionanswer.choice[currentquestionindex][0]);
        ansB.setText(questionanswer.choice[currentquestionindex][1]);
        ansC.setText(questionanswer.choice[currentquestionindex][2]);
        ansD.setText(questionanswer.choice[currentquestionindex][3]);
    }
    void finishquiz(){
        String passstatus="";
        if(score>total_question*0.60)
        { passstatus="passed";
        }else {
            passstatus="failed";
        }
    };


}