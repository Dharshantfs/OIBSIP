package com.example.myquiz;

import kotlin.text.UStringsKt;

public class questionanswer {
    public static String question[]={
            " Name the folk dance of Andhra Pradesh?","When is International Mother Language Day celebrated?",
            "Who penned the book 'Wings of Fire'?"," Who was the first Prime Minister of India?"


    };
    public static String choice[][]={
            { "marana kuthu","thappa kuthu"," Andhra Natyam"," Kuchipudi"},
            {"22 feb","22 nov","2 aug","21 feb"},{"modji","Abdul Kalam","jeyalatha","dani dhars"},
            {"indra gandhi","Jawaharlal Nehru","Amaravati","Ambedker"}


    };
public static String corectans[]={
        " Kuchipudi",
        "21 feb",
        "Abdul Kalam",
        "Jawaharlal Nehru"


};

};


