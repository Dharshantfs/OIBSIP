package com.example.stopwatch;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Handler;
import android.os.SystemClock;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    TextView timer;
    Button a1, p1, r1;
    long millsecondtime, atime, timerbuffer, update = 01;
    Handler handler;
    int sec, min, millisecond;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        timer = (TextView) findViewById(R.id.t);
        a1 = (Button) findViewById(R.id.a);
        p1 = (Button) findViewById(R.id.p);
        r1 = (Button) findViewById(R.id.r);
        handler = new Handler();
        a1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                atime = SystemClock.uptimeMillis();
                handler.postDelayed(runnable, 0);
                r1.setEnabled(false);
            }
        });
        p1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                timerbuffer = millsecondtime;
                handler.removeCallbacks(runnable);
                r1.setEnabled(true);
            }
        });
        r1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                millsecondtime = 0;
                atime = 0;
                timerbuffer = 0;
                update = 0;
                sec = 0;
                min = 0;
                millisecond = 0;
                timer.setText("00.00.00");
            }
        });


    }

    public Runnable runnable = new Runnable() {
        @Override
        public void run() {
            millsecondtime = SystemClock.uptimeMillis() - atime;
            update = timerbuffer + millsecondtime;
            sec = (int) (update / 1000);
            min = sec / 60;
            sec = sec % 60;
            millisecond = (int) (update % 100);
            timer.setText("" + min + "" + String.format("%02d", sec) + ":"
                    + String.format("%03d", millisecond));
            handler.postDelayed(this, 0);

        }
    };

}